#include "LevelStrategy.h"

LevelStrategy::LevelStrategy(){};
LevelStrategy::~LevelStrategy(){};

int P1LStrategy::getbase(){return 2000;}

int P2LStrategy::getbase(){return 5000;}

int P3LStrategy::getbase(){return 10000;}